package com.wilson2403.myapplicationprueba

object Constants {
    val BASE_URL = "https://jsonplaceholder.typicode.com/"
    val REQUEST_CODE = 1
    val RESULT_CODE = 2

}