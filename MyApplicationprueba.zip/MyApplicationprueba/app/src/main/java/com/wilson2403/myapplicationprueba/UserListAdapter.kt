package com.wilson2403.myapplicationprueba

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.util.ArrayList

class UserListAdapter(

    val context: Context,
    var userList: ArrayList<User>,
    private val itemClickListener: (User, position: Int) -> Unit) : RecyclerView.Adapter<UserListAdapter.UserViewHolder>()
    {

    var position: Int = 0

    /* Initialization */
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserViewHolder {
        return UserViewHolder(
            context, LayoutInflater.from(context).inflate(R.layout.layout_user_row, parent, false)
        )
    }

    override fun getItemCount() = userList.size

    override fun onBindViewHolder(holder: UserViewHolder, position: Int) {
        holder.bindView(userList[position], position, itemClickListener)
        this.position = position

    }

    class UserViewHolder(val context: Context, itemView: View) : RecyclerView.ViewHolder(itemView) {

        fun bindView(user: User, selectedPosition: Int, itemClickListener: (User, pos: Int) -> Unit) {


            val id = itemView.findViewById<TextView>(R.id.id)
            val title = itemView.findViewById<TextView>(R.id.title)

            try {
                id.text = "User Id: "+ user.id
                title.text = "text: "+ user.title

                itemView.setOnClickListener { itemClickListener(user, selectedPosition) }

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    public fun addItem(user: User) {
        userList.add(user)
        notifyItemInserted(position)
        notifyItemRangeChanged(position, userList.size)
    }

    public fun removeItem(position: Int) {
        userList.removeAt(position)
        notifyItemRemoved(position)
        notifyItemRangeChanged(position, userList.size)
    }

}