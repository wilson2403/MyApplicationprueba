package com.wilson2403.myapplicationprueba

import retrofit2.Call
import retrofit2.http.GET

interface ApiInterface {
    @GET("posts")
    fun getUsers(): Call<List<User>>
}