package com.wilson2403.myapplicationprueba

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class AddItemDialog(context: Context) : Dialog(context){

    lateinit var id: EditText
    lateinit var title: EditText
    lateinit var btn_add: Button
    var iAddItemCallback: IAddItemCallback? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_item_dialog)
        /* To display full Screen of Dialog */
        window!!.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        init()
    }

    fun init(){
        id = findViewById(R.id.id)
        title = findViewById(R.id.title)
        btn_add = findViewById(R.id.btn_add)

        btn_add.setOnClickListener(View.OnClickListener {
            dismiss()
            if(iAddItemCallback != null){
                iAddItemCallback!!.addItem(User(id.text.toString(),title.text.toString(),""))
                Toast.makeText(context, R.string.user_added, Toast.LENGTH_LONG).show()
            }
        })
    }

    interface IAddItemCallback{
        fun addItem(user: User)
    }

    fun onAddItem(iAddItemCallback: IAddItemCallback){
        this.iAddItemCallback = iAddItemCallback
    }
}
